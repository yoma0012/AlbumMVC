using AlbumsMvc.Models;

namespace AlbumsMvc.Services
{
    public interface IAlbumService
    {
        IEnumerable<Album> GetAll(string? genre = null);
        Album? GetById(int id);
        void Add(Album album);
        IEnumerable<string> GetGenres();
        Album? GetRandomFeatured(string? genre = null);
    }
}