using AlbumsMvc.Models;

namespace AlbumsMvc.Services
{
    public class InMemoryAlbumService : IAlbumService
    {
        private readonly List<Album> _albums = new();
        private int _nextId = 1;
        private readonly Random _rand = new();

        public InMemoryAlbumService()
        {
            _albums.AddRange(new[]
            {
                new Album
                {
                    Id = _nextId++,
                    Title = "Made in Lagos",
                    Artist = "Wizkid",
                    Year = 2020,
                    Genre = "Afrobeats",
                    CoverImageUrl = "https://upload.wikimedia.org/wikipedia/en/6/6d/Wizkid_-_Made_in_Lagos.png"
                },
                new Album
                {
                    Id = _nextId++,
                    Title = "A Good Time",
                    Artist = "Davido",
                    Year = 2019,
                    Genre = "Afropop",
                    CoverImageUrl = "https://upload.wikimedia.org/wikipedia/en/1/14/Davido_-_A_Good_Time.png"
                },
                new Album
                {
                    Id = _nextId++,
                    Title = "African Giant",
                    Artist = "Burna Boy",
                    Year = 2019,
                    Genre = "Afrofusion",
                    CoverImageUrl = "https://upload.wikimedia.org/wikipedia/en/0/05/Burna_Boy_-_African_Giant.png"
                },
                new Album
                {
                    Id = _nextId++,
                    Title = "Love, Damini",
                    Artist = "Burna Boy",
                    Year = 2022,
                    Genre = "Afrofusion",
                    CoverImageUrl = "https://upload.wikimedia.org/wikipedia/en/4/49/Burna_Boy_-_Love%2C_Damini.png"
                },
                new Album
                {
                    Id = _nextId++,
                    Title = "Mr Money With The Vibe",
                    Artist = "Asake",
                    Year = 2022,
                    Genre = "Afrobeats",
                    CoverImageUrl = "https://upload.wikimedia.org/wikipedia/en/2/27/Asake_-_Mr_Money_with_the_Vibe.png"
                }
            });
        }

        public IEnumerable<Album> GetAll(string? genre = null)
        {
            var query = _albums.AsEnumerable();
            if (!string.IsNullOrEmpty(genre))
            {
                query = query.Where(a => a.Genre == genre);
            }
            return query.OrderBy(a => a.Title);
        }

        public Album? GetById(int id) => _albums.FirstOrDefault(a => a.Id == id);

        public void Add(Album album)
        {
            album.Id = _nextId++;
            _albums.Add(album);
        }

        public IEnumerable<string> GetGenres()
            => _albums.Select(a => a.Genre).Distinct().OrderBy(g => g);

        public Album? GetRandomFeatured(string? genre = null)
        {
            var list = GetAll(genre).ToList();
            if (list.Count == 0) return null;
            var index = _rand.Next(list.Count);
            return list[index];
        }
    }
}
