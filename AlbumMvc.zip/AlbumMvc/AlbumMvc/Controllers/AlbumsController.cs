using AlbumsMvc.Models;
using AlbumsMvc.Services;
using AlbumsMvc.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace AlbumsMvc.Controllers
{
    public class AlbumsController : Controller
    {
        private readonly IAlbumService _service;

        public AlbumsController(IAlbumService service)
        {
            _service = service;
        }

       
        public IActionResult Index(string? genre, string? message)
        {
            var vm = new AlbumsViewModel
            {
                Albums = _service.GetAll(genre),
                FeaturedAlbum = _service.GetRandomFeatured(genre),
                Genres = _service.GetGenres(),
                SelectedGenre = genre,
                NewAlbum = new Album { Genre = genre ?? string.Empty },
                Message = message
            };

            return View(vm);
        }

        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Add(AlbumsViewModel vm)
        {
            
            if (!ModelState.IsValid)
            {
                
                vm.Genres = _service.GetGenres();
                vm.Albums = _service.GetAll(vm.SelectedGenre);
                vm.FeaturedAlbum = _service.GetRandomFeatured(vm.SelectedGenre);
                return View("Index", vm);
            }

            _service.Add(vm.NewAlbum);
            
            var genre = vm.SelectedGenre;

            return RedirectToAction("Index", new
            {
                genre,
                message = $"Album \"{vm.NewAlbum.Title}\" added successfully!"
            });
        }

        
        public IActionResult Details(int id)
        {
            var album = _service.GetById(id);
            if (album == null) return NotFound();
            return View(album);
        }
    }
}