using AlbumsMvc.Models;

namespace AlbumsMvc.ViewModels
{
    public class AlbumsViewModel
    {
        public IEnumerable<Album> Albums { get; set; } = Enumerable.Empty<Album>();
        public Album? FeaturedAlbum { get; set; }

        public IEnumerable<string> Genres { get; set; } = Enumerable.Empty<string>();
        public string? SelectedGenre { get; set; }
        
        public Album NewAlbum { get; set; } = new();

        public string? Message { get; set; }
    }
}