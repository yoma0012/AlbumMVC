using System.ComponentModel.DataAnnotations;

namespace AlbumsMvc.Models
{
    public class Album
    {
        public int Id { get; set; }

        [Required, StringLength(100)]
        public string Title { get; set; } = string.Empty;

        [Required, StringLength(100)]
        public string Artist { get; set; } = string.Empty;

        [Required, Range(1900, 2100)]
        public int Year { get; set; }

        [Required, StringLength(50)]
        public string Genre { get; set; } = string.Empty;

        [Required, Url]
        [Display(Name = "Cover image URL")]
        public string CoverImageUrl { get; set; } = string.Empty;
    }
}